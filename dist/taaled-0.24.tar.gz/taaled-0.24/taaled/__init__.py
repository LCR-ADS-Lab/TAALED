name = "ld"
from taaled.ld import *